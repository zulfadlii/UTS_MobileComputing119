package com.example.mobcomzull

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun CourseList(courses: List<Course>) {
    LazyColumn(
            modifier = Modifier.fillMaxSize()
    ) {
        items(courses) { course ->
            CourseItem(course)
        }
    }
}

@Composable
fun CourseItem(course: Course) {
    var expanded by remember { mutableStateOf(false) }

    Column(
            modifier = Modifier
                    .padding(8.dp)
                    .fillMaxSize(),
            verticalArrangement = Arrangement.Center
    ) {
        BasicTextField(
                value = course.nama,
                onValueChange = { /* Handle text change if needed */ },
                textStyle = TextStyle(color = Color.Black),
                modifier = Modifier.padding(8.dp)
        )

        if (expanded) {
            BasicTextField(
                    value = course.sks.toString(),
                    onValueChange = { /* Handle text change if needed */ },
                    textStyle = TextStyle(color = Color.Black),
                    modifier = Modifier.padding(8.dp)
            )
        } else {
            Text(text = course.sks.toString(), modifier = Modifier.padding(8.dp))
        }

        Image(
                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                contentDescription = null,
                modifier = Modifier
                        .size(50.dp)
                        .padding(8.dp)
        )

        IconButton(
                onClick = { expanded = !expanded },
                modifier = Modifier.padding(8.dp)
        ) {
            Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null
            )
        }
    }
}
